create view pg_stat_io
            (backend_type, object, context, reads, read_time, writes, write_time, writebacks, writeback_time, extends,
             extend_time, op_bytes, hits, evictions, reuses, fsyncs, fsync_time, stats_reset)
as
SELECT backend_type,
       object,
       context,
       reads,
       read_time,
       writes,
       write_time,
       writebacks,
       writeback_time,
       extends,
       extend_time,
       op_bytes,
       hits,
       evictions,
       reuses,
       fsyncs,
       fsync_time,
       stats_reset
FROM pg_stat_get_io() b(backend_type, object, context, reads, read_time, writes, write_time, writebacks, writeback_time,
                        extends, extend_time, op_bytes, hits, evictions, reuses, fsyncs, fsync_time, stats_reset);

alter table pg_stat_io
    owner to root;

grant select on pg_stat_io to public;

